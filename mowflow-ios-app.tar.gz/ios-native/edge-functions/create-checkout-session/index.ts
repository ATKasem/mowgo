// Supabase Edge Function: create-checkout-session
// Creates a Stripe Checkout session for subscription upgrades.
//
// Deploy: supabase functions deploy create-checkout-session
//
// Required env vars:
//   STRIPE_SECRET_KEY     — your Stripe secret key
//   STRIPE_PRICE_SOLO     — Stripe Price ID for Solo tier (price_xxx)
//   STRIPE_PRICE_CREW     — Stripe Price ID for Crew tier (price_xxx)

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const tierToEnvKey: Record<string, string> = {
  solo: "STRIPE_PRICE_SOLO",
  crew: "STRIPE_PRICE_CREW",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { tier } = await req.json();

    if (!tier || !tierToEnvKey[tier]) {
      return new Response(
        JSON.stringify({ error: "tier must be 'solo' or 'crew'" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    const priceId = Deno.env.get(tierToEnvKey[tier]);

    if (!stripeKey || !priceId) {
      return new Response(
        JSON.stringify({ error: "Stripe not fully configured" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Look up or create Stripe customer
    const { data: profile } = await supabase
      .from("profiles")
      .select("stripe_customer_id")
      .eq("id", user.id)
      .single();

    let customerId = profile?.stripe_customer_id;

    if (!customerId) {
      // Create a new Stripe customer
      const custResp = await fetch("https://api.stripe.com/v1/customers", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${stripeKey}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          email: user.email ?? "",
          "metadata[supabase_user_id]": user.id,
        }).toString(),
      });
      const customer = await custResp.json();
      customerId = customer.id;

      // Save the customer ID to the profile
      await supabase
        .from("profiles")
        .update({ stripe_customer_id: customerId })
        .eq("id", user.id);
    }

    // Create Checkout Session
    const sessionResp = await fetch(
      "https://api.stripe.com/v1/checkout/sessions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${stripeKey}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          customer: customerId,
          mode: "subscription",
          "line_items[0][price]": priceId,
          "line_items[0][quantity]": "1",
          success_url: "https://mowflow.app/settings?upgraded=true",
          cancel_url: "https://mowflow.app/settings",
          "subscription_data[metadata][user_id]": user.id,
          "subscription_data[metadata][tier]": tier,
        }).toString(),
      }
    );

    if (!sessionResp.ok) {
      const err = await sessionResp.text();
      console.error("Stripe checkout error:", err);
      return new Response(
        JSON.stringify({ error: "Could not create checkout session" }),
        {
          status: 502,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const session = await sessionResp.json();

    return new Response(JSON.stringify({ url: session.url }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("create-checkout-session error:", err);
    return new Response(JSON.stringify({ error: "Internal error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
