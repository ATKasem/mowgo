//
//  SupabaseService.swift
//  MowGo
//
//  REST API wrapper for Supabase PostgREST.
//  The anon key IS public — it's the same key shipped in every web client.
//  Never put the service_role key in client code.
//
//  Config is read from Info.plist (set via build settings / xcconfig).
//

import Foundation
import Security

actor SupabaseService {
    static let shared = SupabaseService()

    private let baseURL: String
    private let anonKey: String

    private let decoder: JSONDecoder = {
        let d = JSONDecoder()
        d.keyDecodingStrategy = .convertFromSnakeCase
        return d
    }()

    private let encoder: JSONEncoder = {
        let e = JSONEncoder()
        e.keyEncodingStrategy = .convertToSnakeCase
        return e
    }()

    // MARK: - Auth

    private(set) var token: String?
    private var refreshToken: String?
    private var tokenExpiry: Date?

    var isAuthenticated: Bool {
        guard let token, let expiry = tokenExpiry else { return false }
        return !token.isEmpty && Date() < expiry
    }

    func ensureAuthenticated() async -> Bool {
        if isAuthenticated { return true }
        guard refreshToken?.isEmpty == false else { return false }
        do {
            try await refreshAccessToken()
            return isAuthenticated
        } catch {
            await signOut()
            return false
        }
    }

    // MARK: - Init (reads from Info.plist)
    //  Xcode with GENERATE_INFOPLIST_FILE strips the INFOPLIST_KEY_ prefix,
    //  so INFOPLIST_KEY_SUPABASE_URL → Info.plist key "SUPABASE_URL".
    //  We check both formats for backward compatibility.
    private init() {
        let info = Bundle.main.infoDictionary
        self.baseURL = (info?["SUPABASE_URL"] as? String)
                     ?? (info?["SupabaseURL"] as? String)
                     ?? ""
        self.anonKey = (info?["SUPABASE_ANON_KEY"] as? String)
                     ?? (info?["SupabaseAnonKey"] as? String)
                     ?? ""
    }

    // MARK: - Config check (for preview/testing)

    /// Returns true if config is valid and not using placeholder values.
    var isConfigured: Bool {
        return !baseURL.contains("YOUR_") && !anonKey.contains("YOUR_") &&
               !baseURL.isEmpty && !anonKey.isEmpty
    }

    // MARK: - Auth

    func signIn(email: String, password: String) async throws -> String {
        let body: [String: Any] = ["email": email, "password": password]
        let data = try await request(
            "POST",
            "/auth/v1/token?grant_type=password",
            body: body,
            allowsTokenRefresh: false
        )
        let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        guard let accessToken = json?["access_token"] as? String else {
            throw AuthError.invalidCredentials
        }
        token = accessToken
        refreshToken = json?["refresh_token"] as? String
        // Parse expires_in (seconds from now)
        if let expiresIn = json?["expires_in"] as? Double {
            tokenExpiry = Date().addingTimeInterval(expiresIn - 300) // 5 min buffer
        }
        saveSession()
        return accessToken
    }

    func signUp(email: String, password: String) async throws {
        let body: [String: Any] = ["email": email, "password": password]
        _ = try await request(
            "POST",
            "/auth/v1/signup",
            body: body,
            allowsTokenRefresh: false
        )
    }

    func signOut() async {
        _cachedUserId = nil
        token = nil
        refreshToken = nil
        tokenExpiry = nil
        clearSession()
    }

    // Cache the user ID to avoid repeated network calls on every fetch.
    // getCurrentUserId() was called 3x per loadAll() (jobs, clients, invoices).
    private var _cachedUserId: UUID?

    func getCurrentUserId() async throws -> UUID? {
        if let cached = _cachedUserId { return cached }
        // Try refresh if token is expired
        if !isAuthenticated, let _ = refreshToken {
            try await refreshAccessToken()
        }
        guard token != nil else { return nil }
        let data = try await request("GET", "/auth/v1/user")
        let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        guard let idStr = json?["id"] as? String, let id = UUID(uuidString: idStr) else {
            return nil
        }
        _cachedUserId = id
        return id
    }

    // MARK: - Token persistence
    // TODO: Migrate token storage from UserDefaults to Keychain for production.
    // UserDefaults are backed up to iCloud and are not encrypted at rest.
    // Use Security.framework (SecItemAdd/SecItemCopyMatching) or a wrapper
    // like KeychainAccess to store sb_token and sb_refresh_token securely.

    // MARK: - Keychain Helpers

    private func saveToKeychain(key: String, value: String) {
        let data = Data(value.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "com.mowgo.auth",
            kSecAttrAccount as String: key,
        ]
        SecItemDelete(query as CFDictionary) // Remove any existing item
        let addQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "com.mowgo.auth",
            kSecAttrAccount as String: key,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlock,
        ]
        SecItemAdd(addQuery as CFDictionary, nil)
    }

    private func loadFromKeychain(key: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "com.mowgo.auth",
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess,
              let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func deleteFromKeychain(key: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "com.mowgo.auth",
            kSecAttrAccount as String: key,
        ]
        SecItemDelete(query as CFDictionary)
    }

    // MARK: - Session persistence (Keychain-backed)

    private func saveSession() {
        if let t = token { saveToKeychain(key: "sb_token", value: t) }
        if let rt = refreshToken { saveToKeychain(key: "sb_refresh_token", value: rt) }
        if let exp = tokenExpiry {
            let ts = String(exp.timeIntervalSince1970)
            saveToKeychain(key: "sb_token_expiry", value: ts)
        }
    }

    func restoreSession() async -> Bool {
        // Try Keychain first, then fall back to UserDefaults (migration)
        var t = loadFromKeychain(key: "sb_token")
        if t == nil || t!.isEmpty {
            t = UserDefaults.standard.string(forKey: "sb_token")
            if let migrated = t, !migrated.isEmpty {
                // Migrate existing UserDefaults tokens to Keychain
                saveToKeychain(key: "sb_token", value: migrated)
                if let rt = UserDefaults.standard.string(forKey: "sb_refresh_token") {
                    saveToKeychain(key: "sb_refresh_token", value: rt)
                }
                if let exp = UserDefaults.standard.string(forKey: "sb_token_expiry") {
                    saveToKeychain(key: "sb_token_expiry", value: exp)
                }
                // Clear UserDefaults copies after migration
                UserDefaults.standard.removeObject(forKey: "sb_token")
                UserDefaults.standard.removeObject(forKey: "sb_refresh_token")
                UserDefaults.standard.removeObject(forKey: "sb_token_expiry")
            }
        }
        guard let t = t, !t.isEmpty else {
            await signOut()
            return false
        }
        token = t
        refreshToken = loadFromKeychain(key: "sb_refresh_token")
        if let ts = loadFromKeychain(key: "sb_token_expiry"),
           let interval = TimeInterval(ts) {
            tokenExpiry = Date(timeIntervalSince1970: interval)
        }
        if isAuthenticated { return true }

        guard refreshToken?.isEmpty == false else {
            await signOut()
            return false
        }
        do {
            try await refreshAccessToken()
            return isAuthenticated
        } catch {
            await signOut()
            return false
        }
    }

    private func clearSession() {
        deleteFromKeychain(key: "sb_token")
        deleteFromKeychain(key: "sb_refresh_token")
        deleteFromKeychain(key: "sb_token_expiry")
    }

    // If a refresh is already in flight, new callers await the existing
    // task instead of silently getting no token update.
    private var refreshTask: Task<Void, Error>?

    private func refreshAccessToken() async throws {
        guard let rt = refreshToken else { return }
        // If a refresh is already in flight, wait for it to complete
        if let existing = refreshTask {
            do {
                try await existing.value
            } catch {
                await signOut()
                throw error
            }
            // After the in-flight refresh, check if we now have a valid token
            guard !isAuthenticated else { return }
        }
        refreshTask = Task {
            defer { refreshTask = nil }
            let body: [String: Any] = ["refresh_token": rt]
            let data = try await request(
                "POST",
                "/auth/v1/token?grant_type=refresh_token",
                body: body,
                allowsTokenRefresh: false
            )
            let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
            if let accessToken = json?["access_token"] as? String {
                token = accessToken
                refreshToken = json?["refresh_token"] as? String
                if let expiresIn = json?["expires_in"] as? Double {
                    tokenExpiry = Date().addingTimeInterval(expiresIn - 300)
                }
                saveSession()
            } else {
                await signOut()
                throw AuthError.sessionExpired
            }
        }
        do {
            try await refreshTask?.value
        } catch {
            await signOut()
            throw error
        }
    }

    // MARK: - CRUD (filtered by user_id)

    func fetch<T: Decodable>(_ table: String, query: [String: String] = [:]) async throws -> [T] {
        var q = query
        if let uid = try? await getCurrentUserId(), table != "profiles" {
            q["user_id"] = "eq.\(uid.uuidString)"
        }
        var path = "/rest/v1/\(table)?select=*"
        for (k, v) in q { path += "&\(k)=\(v.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? v)" }
        let data = try await request("GET", path)
        return try decoder.decode([T].self, from: data)
    }

    func fetchJobs() async throws -> [Job] {
        guard let uid = try? await getCurrentUserId() else { return [] }
        let path = "/rest/v1/jobs?select=*,clients!left(*)&user_id=eq.\(uid.uuidString)&order=scheduled_date.asc"
        let data = try await request("GET", path)
        return try decoder.decode([Job].self, from: data)
    }

    func fetchInvoices() async throws -> [Invoice] {
        guard let uid = try? await getCurrentUserId() else { return [] }
        let path = "/rest/v1/invoices?select=*,clients!left(name)&user_id=eq.\(uid.uuidString)&order=created_at.desc"
        let data = try await request("GET", path)
        return try decoder.decode([Invoice].self, from: data)
    }

    func fetchProfile() async throws -> UserProfile? {
        guard let uid = try? await getCurrentUserId() else { return nil }
        let path = "/rest/v1/profiles?select=*&id=eq.\(uid.uuidString)"
        let data = try await request("GET", path)
        let profiles = try decoder.decode([UserProfile].self, from: data)
        return profiles.first
    }

    func insert<Payload: Encodable, Result: Decodable>(
        _ table: String,
        _ item: Payload
    ) async throws -> Result {
        let data = try await request("POST", "/rest/v1/\(table)",
            body: try JSONSerialization.jsonObject(with: encoder.encode(item)),
            prefer: "return=representation")
        let items = try decoder.decode([Result].self, from: data)
        guard let first = items.first else { throw SupabaseError.noRows }
        return first
    }

    func update<T: Encodable>(_ table: String, id: UUID, _ item: T) async throws {
        _ = try await request("PATCH", "/rest/v1/\(table)?id=eq.\(id.uuidString)",
            body: try JSONSerialization.jsonObject(with: encoder.encode(item)))
    }

    func delete(_ table: String, id: UUID) async throws {
        _ = try await request("DELETE", "/rest/v1/\(table)?id=eq.\(id.uuidString)")
    }

    // MARK: - Edge Functions

    func requestFunction(_ name: String, body: [String: Any]) async throws -> Data {
        let path = "/functions/v1/\(name)"
        return try await request("POST", path, body: body)
    }

    // MARK: - HTTP

    private func request(
        _ method: String,
        _ path: String,
        body: Any? = nil,
        prefer: String? = nil,
        allowsTokenRefresh: Bool = true
    ) async throws -> Data {
        guard let url = URL(string: "\(baseURL)\(path)") else {
            throw SupabaseError.network
        }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue(anonKey, forHTTPHeaderField: "apikey")
        req.timeoutInterval = 30

        if let token {
            req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let p = prefer { req.setValue(p, forHTTPHeaderField: "Prefer") }

        if let body {
            req.httpBody = try JSONSerialization.data(withJSONObject: body)
        }

        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else {
            throw SupabaseError.network
        }
        guard (200...299).contains(http.statusCode) else {
            if http.statusCode == 401, allowsTokenRefresh, refreshToken != nil {
                try await refreshAccessToken()
                return try await request(
                    method,
                    path,
                    body: body,
                    prefer: prefer,
                    allowsTokenRefresh: false
                )
            }
            throw SupabaseError.httpStatus(http.statusCode)
        }
        return data
    }
}

// MARK: - Errors

enum AuthError: LocalizedError {
    case invalidCredentials
    case signUpFailed
    case sessionExpired
    var errorDescription: String? {
        switch self {
        case .invalidCredentials: "Invalid email or password."
        case .signUpFailed: "Could not create account. Please try again."
        case .sessionExpired: "Session expired. Please sign in again."
        }
    }
}

enum SupabaseError: LocalizedError {
    case network, noRows, httpStatus(Int), decodingFailed
    var errorDescription: String? {
        switch self {
        case .network: "Network error. Check your connection."
        case .noRows: "No data returned."
        case .httpStatus(let code): "Server error (\(code))."
        case .decodingFailed: "Could not parse server response."
        }
    }
}
